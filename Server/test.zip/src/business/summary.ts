import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const getSummaryFromAI = async (text: string) => {
  try {
    console.log("inside get Summary");
    const response = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        {
          role: "user",
          content: `Summarize the content below in 2 lines, ${text}`,
        },
      ],
    });

    console.log(response.choices[0].message.content);
    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("An error occurred", error);
    throw new Error("Failed to generate summary");
  }
};
